// SPDX-License-Identifier: Apache-2.0
// Local OpenCV DNN port of OpenCV Zoo's MediaPipe palm/hand example.
// Upstream revision, Apache-2.0 notices and model hashes: data/hand-models.md.
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.opencv.core.*;
import org.opencv.dnn.Dnn;
import org.opencv.dnn.Net;
import org.opencv.imgproc.Imgproc;

public class HandTracker {
  private final Net palmNet, poseNet;
  private final float[][] anchors = new float[2016][2];
  public float palmThreshold = .55f, handThreshold = .75f;

  public HandTracker(String palmPath, String posePath) {
    palmNet = readModel(palmPath);
    poseNet = readModel(posePath);
    if (palmNet.empty() || poseNet.empty()) throw new IllegalStateException("Hand models unavailable");
    palmNet.setPreferableBackend(Dnn.DNN_BACKEND_OPENCV);
    poseNet.setPreferableBackend(Dnn.DNN_BACKEND_OPENCV);
    palmNet.setPreferableTarget(Dnn.DNN_TARGET_CPU);
    poseNet.setPreferableTarget(Dnn.DNN_TARGET_CPU);
    int i=0;
    for(int grid : new int[]{24,12}) for(int y=0;y<grid;y++) for(int x=0;x<grid;x++)
      for(int repeat=0;repeat<(grid==24?2:6);repeat++) {
        anchors[i][0]=(x+.5f)/grid; anchors[i++][1]=(y+.5f)/grid;
      }
  }
  private static Net readModel(String path) {
    // OpenCV's Windows file API cannot reliably open Unicode paths; Java can.
    try {
      MatOfByte bytes=new MatOfByte(java.nio.file.Files.readAllBytes(java.nio.file.Path.of(path)));
      try { return Dnn.readNetFromONNX(bytes); } finally { bytes.release(); }
    } catch(java.io.IOException error) { throw new IllegalStateException("Cannot read the bundled hand model",error); }
  }

  public static class Hand {
    public final float[][] points, world;
    public final float confidence, handedness;
    public final Rect box;
    public boolean isL;
    public String hint;
    public Hand(float[][] points,float[][] world,float confidence,float handedness) {
      this.points=points; this.world=world; this.confidence=confidence; this.handedness=handedness;
      float x=Float.MAX_VALUE,y=x,r=-x,b=-x;
      for(float[] p:points) { x=Math.min(x,p[0]); y=Math.min(y,p[1]); r=Math.max(r,p[0]); b=Math.max(b,p[1]); }
      box=new Rect((int)x,(int)y,Math.max(1,(int)(r-x)),Math.max(1,(int)(b-y)));
      hint=classify(this); isL=hint.equals("L READY");
    }
  }
  private static class Palm {
    float x,y,w,h,score;
    float[][] points=new float[7][2];
  }

  // Input is BGR; outputs remain in the original camera coordinate system.
  public List<Hand> detect(Mat frame) {
    List<Hand> hands=new ArrayList<Hand>();
    for(Palm p:palms(frame)) {
      Hand hand=pose(frame,p);
      if(hand==null) continue;
      boolean duplicate=false;
      for(Hand existing:hands) {
        float scale=(distance(hand.points[0],hand.points[9])+distance(existing.points[0],existing.points[9]))*.5f;
        if(distance(hand.points[0],existing.points[0])<scale*.65f) duplicate=true;
      }
      if(!duplicate) hands.add(hand);
      if(hands.size()==2) break;
    }
    return hands;
  }
  private List<Palm> palms(Mat frame) {
    double ratio=192.0/Math.max(frame.cols(),frame.rows());
    int w=(int)(frame.cols()*ratio),h=(int)(frame.rows()*ratio),left=(192-w)/2,top=(192-h)/2;
    Mat resized=new Mat(),padded=new Mat();
    Imgproc.resize(frame,resized,new Size(w,h));
    Core.copyMakeBorder(resized,padded,top,192-h-top,left,192-w-left,Core.BORDER_CONSTANT,Scalar.all(0));
    Mat blob=nhwc(padded,192);
    List<Mat> output=new ArrayList<Mat>();
    List<Palm> candidates=new ArrayList<Palm>(),kept=new ArrayList<Palm>();
    try {
      palmNet.setInput(blob); palmNet.forward(output,palmNet.getUnconnectedOutLayersNames());
      float[] boxes=null,scores=null;
      for(Mat m:output) { if(m.total()==2016*18) boxes=values(m); else if(m.total()==2016) scores=values(m); }
      if(boxes==null || scores==null) throw new IllegalStateException("Unexpected palm model outputs");
      float scale=Math.max(frame.cols(),frame.rows());
      for(int i=0;i<2016;i++) {
        float score=(float)(1/(1+Math.exp(-scores[i])));
        if(score<palmThreshold) continue;
        int j=i*18; Palm p=new Palm(); p.score=score;
        p.w=boxes[j+2]/192*scale; p.h=boxes[j+3]/192*scale;
        p.x=(boxes[j]/192+anchors[i][0])*scale-(float)(left/ratio)-p.w/2;
        p.y=(boxes[j+1]/192+anchors[i][1])*scale-(float)(top/ratio)-p.h/2;
        if(p.w<5 || p.h<5) continue;
        for(int k=0;k<7;k++) {
          p.points[k][0]=(boxes[j+4+k*2]/192+anchors[i][0])*scale-(float)(left/ratio);
          p.points[k][1]=(boxes[j+5+k*2]/192+anchors[i][1])*scale-(float)(top/ratio);
        }
        candidates.add(p);
      }
      candidates.sort(Comparator.comparingDouble((Palm p)->-p.score));
      for(Palm p:candidates) {
        boolean overlaps=false;
        for(Palm q:kept) {
          float intersection=Math.max(0,Math.min(p.x+p.w,q.x+q.w)-Math.max(p.x,q.x))
            *Math.max(0,Math.min(p.y+p.h,q.y+q.h)-Math.max(p.y,q.y));
          if(intersection/(p.w*p.h+q.w*q.h-intersection)>.30f) overlaps=true;
        }
        if(!overlaps) kept.add(p);
        if(kept.size()==4) break;
      }
      return kept;
    } finally { resized.release(); padded.release(); blob.release(); for(Mat m:output) m.release(); }
  }
  private Hand pose(Mat frame,Palm palm) {
    // Rotate the palm's wrist->middle MCP axis upright, then use the upstream
    // shift/enlargement (0,-.4) and 3x crop. One affine avoids intermediate crops.
    double dx=palm.points[2][0]-palm.points[0][0],dy=palm.points[2][1]-palm.points[0][1];
    double angle=Math.PI/2+Math.atan2(dy,dx),c=Math.cos(angle),s=Math.sin(angle);
    double minX=Double.MAX_VALUE,minY=minX,maxX=-minX,maxY=-minX;
    for(float[] p:palm.points) {
      double x=c*p[0]+s*p[1],y=-s*p[0]+c*p[1];
      minX=Math.min(minX,x); maxX=Math.max(maxX,x); minY=Math.min(minY,y); maxY=Math.max(maxY,y);
    }
    double cx=(minX+maxX)/2,cy=(minY+maxY)/2-.4*(maxY-minY),side=3*Math.max(maxX-minX,maxY-minY);
    if(side<10) return null;
    double scale=224/side;
    Mat affine=new Mat(2,3,CvType.CV_64F),crop=new Mat();
    affine.put(0,0,c*scale,s*scale,112-cx*scale,-s*scale,c*scale,112-cy*scale);
    Imgproc.warpAffine(frame,crop,affine,new Size(224,224),Imgproc.INTER_LINEAR,Core.BORDER_CONSTANT,Scalar.all(0));
    Mat blob=nhwc(crop,224); List<Mat> outputs=new ArrayList<Mat>();
    try {
      poseNet.setInput(blob); poseNet.forward(outputs,poseNet.getUnconnectedOutLayersNames());
      // The Zoo model's ordered output contract is screen xyz, presence,
      // handedness, world xyz; verify the shape before reading it.
      if(outputs.size()!=4 || outputs.get(0).total()!=63 || outputs.get(1).total()!=1
          || outputs.get(2).total()!=1 || outputs.get(3).total()!=63)
        throw new IllegalStateException("Unexpected hand model outputs");
      float confidence=values(outputs.get(1))[0];
      if(confidence<handThreshold) return null;
      float[] xyz=values(outputs.get(0)),world=values(outputs.get(3));
      float[][] points=new float[21][3],worldPoints=new float[21][3];
      for(int i=0;i<21;i++) {
        double x=cx+(xyz[i*3]-112)/scale,y=cy+(xyz[i*3+1]-112)/scale;
        points[i][0]=(float)(c*x-s*y); points[i][1]=(float)(s*x+c*y); points[i][2]=(float)(xyz[i*3+2]/scale);
        System.arraycopy(world,i*3,worldPoints[i],0,3);
      }
      return new Hand(points,worldPoints,confidence,values(outputs.get(2))[0]);
    } finally { affine.release(); crop.release(); blob.release(); for(Mat m:outputs) m.release(); }
  }
  private static Mat nhwc(Mat bgr,int size) {
    Mat rgb=new Mat(),normalized=new Mat();
    Imgproc.cvtColor(bgr,rgb,Imgproc.COLOR_BGR2RGB); rgb.convertTo(normalized,CvType.CV_32FC3,1/255.0);
    Mat blob=normalized.reshape(1,new int[]{1,size,size,3});
    rgb.release(); normalized.release(); return blob;
  }
  private static float[] values(Mat m) {
    float[] data=new float[(int)m.total()*m.channels()]; m.get(new int[m.dims()],data); return data;
  }
  public static float distance(float[] a,float[] b) {
    double sum=0; for(int i=0;i<Math.min(a.length,b.length);i++) sum+=(a[i]-b[i])*(a[i]-b[i]);
    return (float)Math.sqrt(sum);
  }
  private static double joint(float[] a,float[] b,float[] c) {
    double dot=0,aa=0,bb=0;
    for(int i=0;i<3;i++) { double u=a[i]-b[i],v=c[i]-b[i]; dot+=u*v; aa+=u*u; bb+=v*v; }
    return Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,dot/Math.max(1e-12,Math.sqrt(aa*bb))))));
  }
  public static String classify(Hand hand) {
    float[][] p=hand.world;
    float size=distance(p[0],p[9]);
    if(size<.0001f) return "SHOW WHOLE HAND";
    if(joint(p[5],p[6],p[7])<145 || joint(p[6],p[7],p[8])<145
        || distance(p[0],p[8])<distance(p[0],p[6])*1.12f) return "EXTEND INDEX";
    if(joint(p[2],p[3],p[4])<140 || distance(p[4],p[5])<size*.50f) return "OPEN THUMB";
    int curled=0;
    for(int m:new int[]{9,13,17}) if(joint(p[m],p[m+1],p[m+2])<155
        || distance(p[0],p[m+3])<distance(p[0],p[m+1])*1.08f) curled++;
    if(curled<2) return "FOLD OTHER FINGERS";
    float[][] q=hand.points;
    double ix=q[8][0]-q[5][0],iy=q[8][1]-q[5][1],tx=q[4][0]-q[2][0],ty=q[4][1]-q[2][1];
    double cosine=(ix*tx+iy*ty)/Math.max(1e-6,Math.hypot(ix,iy)*Math.hypot(tx,ty));
    if(cosine>.55 || cosine<-.65) return "MAKE A RIGHT ANGLE";
    return "L READY";
  }
  public static boolean formsFrame(Hand a,Hand b) {
    if(!a.isL || !b.isL) return false;
    float sa=distance(a.points[0],a.points[9]),sb=distance(b.points[0],b.points[9]);
    if(sa<5 || sb<5 || sa/sb<.35f || sa/sb>2.85f) return false;
    float[][] p=a.points,q=b.points;
    double dx=q[5][0]-p[5][0],dy=q[5][1]-p[5][1],separation=Math.hypot(dx,dy);
    if(separation<Math.max(sa,sb)*.8 || separation>Math.max(sa,sb)*9) return false;
    double[][] u=axes(p),v=axes(q);
    for(double[] axis:u) if((axis[0]*dx+axis[1]*dy)/separation<-.30) return false;
    for(double[] axis:v) if((axis[0]*dx+axis[1]*dy)/separation>.30) return false;
    double direct=Math.min(-dot(u[0],v[0]),-dot(u[1],v[1]));
    double swapped=Math.min(-dot(u[0],v[1]),-dot(u[1],v[0]));
    return Math.max(direct,swapped)>.5;
  }
  private static double[][] axes(float[][] p) {
    double[][] result={{p[8][0]-p[5][0],p[8][1]-p[5][1]}, {p[4][0]-p[2][0],p[4][1]-p[2][1]}};
    for(double[] axis:result) { double n=Math.max(1e-6,Math.hypot(axis[0],axis[1])); axis[0]/=n; axis[1]/=n; }
    return result;
  }
  private static double dot(double[] a,double[] b) { return a[0]*b[0]+a[1]*b[1]; }
}
