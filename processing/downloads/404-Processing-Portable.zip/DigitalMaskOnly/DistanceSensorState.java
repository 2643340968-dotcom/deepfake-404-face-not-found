/** A single immutable distance sample shared by the serial and drawing threads. */
public final class DistanceSensorState {
  public static final int MAX_AGE_MS = 1200;
  private static final Sample UNKNOWN = new Sample(-1, -10000);
  private volatile Sample latest = UNKNOWN;
  private volatile int packetAt = -10000;

  public synchronized boolean accept(String line, int now) {
    if (line == null) return false;
    String[] fields = line.trim().split(",", -1);
    if (fields.length != 4 || !fields[0].equals("D")
        || !(fields[3].equals("0") || fields[3].equals("1"))) return false;
    try {
      float cm = Float.parseFloat(fields[2]);
      packetAt = now;
      if (fields[3].equals("1") && Float.isFinite(cm) && cm >= 2 && cm <= 400) {
        latest = new Sample(cm, now);
      }
      return true;
    } catch (NumberFormatException ignored) { return false; }
  }

  public Sample snapshot(int now) {
    Sample sample = latest;
    int age = now - sample.at;
    return sample.cm >= 2 && age >= 0 && age < MAX_AGE_MS ? sample : UNKNOWN;
  }

  public int lastPacketAt() { return packetAt; }
  public synchronized void reset() { latest = UNKNOWN; packetAt = -10000; }

  public static final class Sample {
    public final float cm;
    public final int at;
    private Sample(float cm, int at) { this.cm = cm; this.at = at; }
  }
}
