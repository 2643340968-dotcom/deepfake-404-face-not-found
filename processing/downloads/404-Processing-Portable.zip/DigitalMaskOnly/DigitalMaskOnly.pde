import processing.video.Capture;
import processing.serial.Serial;
import org.opencv.core.Mat;
import org.opencv.core.CvType;
import org.opencv.core.Size;
import org.opencv.core.Rect;
import org.opencv.objdetect.FaceDetectorYN;
import java.util.ArrayList;

// Keep the code/ and data/ folders from the supplied Mac package.
String SERIAL_PORT = ""; // Auto-select ONE Arduino USB port, or enter exact port.
int CAMERA_INDEX = 0;
float NEAR_CM = 2, FAR_CM = 50; // User-selected continuous proximity range (cm).
int GESTURE_HOLD_MS = 600;
int GESTURE_GAP_MS = 300; // Tolerate one missed inference without using motion.
int HANDS_GONE_MS = 700; // Hide after both hands leave, without flickering on a missed inference.
int FACE_OCCLUSION_MS = 4500; // Brief occlusion grace; never retain an unverified face indefinitely.

// Base V1 typography; keep the reference eyes open and the chin tapered.
int MASK_COLUMNS = 56;
int MASK_ROWS = 48;
float MASK_GLOW_RADIUS = 3.5f;
float MASK_GLOW_STRENGTH = 175;
int MASK_DIGIT_STEP_MS = 220; // A small group changes each step.
int MASK_DIGIT_GROUPS = 8;    // Each digit flips about every 1.76 seconds.
float FACE_BLUR_RADIUS = 3.5f;
float FACE_BLUR_OPACITY = 215; // Translucent blurred camera pixels below the digits.
float FACE_BLUR_FEATHER = 0.03f;
final int FACE_BLUR_SAMPLE_SIZE = 64, FACE_BLUR_LAYER_SIZE = 128;
final int MASK_TEXTURE_SIZE = 640;
final float MASK_FACE_SIZE = 400, MASK_TOP_PADDING = 48;

Capture camera;
volatile Serial arduino;
FaceDetectorYN faceDetector;
Mat faceInput, faceDetections;
PImage small;
PFont maskFont;
PGraphics maskCharacters, maskGlow, maskComposite;
PImage maskSprite;
PImage maskGlowSnapshot;
PImage faceBlurSample, faceBlurLayer;
int[] faceBlurAlpha;
float cachedFaceBlurRisk = -1, cachedFaceBlurOpacity = -1, cachedFaceBlurFeather = -1;
int maskSpriteX = 0, maskSpriteY = 0;
float cachedMaskRisk = -1, cachedGlowRadius = -1, cachedGlowStrength = -1;
int cachedMaskPhase = -1, cachedMaskColumns = -1, cachedMaskRows = -1;
int cachedDigitPhase = -1, cachedDigitStep = -1, cachedDigitGroups = -1;
Rect face = null, previousFace = null;
int faceSeenAt = -10000;
boolean faceVisible = false;
final int CW = 320, CH = 240;
HandTracker handTracker;
java.util.List<HandTracker.Hand> hands = new ArrayList<HandTracker.Hand>();
Mat handFrame;
byte[] handBytes = new byte[CW * CH * 3];
boolean leftL = false, rightL = false, gestureDetected = false;
float risk = 0;
String gestureHint = "SHOW BOTH HANDS";
float handAnalysisMs = 0;
Rect leftHandBox = null, rightHandBox = null;
int gestureSince = -1, lastGestureAt = -10000, gestureSamples = 0;
int lastHandAt = -10000;
boolean protectionLatched = false;
int frameAt = -10000, lastAnalysis = -10000, lastDraw = 0;
int retryAt = -10000, openedAt = -10000;
DistanceSensorState sensorState = new DistanceSensorState();
float distanceCm = -1; // Draw-thread snapshot; serial callbacks never modify this value.
String serialMessage = "";
boolean webMode = Boolean.getBoolean("dpm.web"), sessionActive = false;
boolean portableMode = false;
String portableError = "";
WebExperience web;
String engineError = "", maskShape = "base", maskText = "01";
int maskColour = 0xfffff8eb, maskMovement = 35, maskDensity = 72, configVersion = 0;
int lastWebPublish = -10000;
float maskWidth = 1;

public void settings() { size(960, 720); }
public void setup() {
  frameRate(30); textSize(14); background(20);
  portableMode=java.nio.file.Files.isRegularFile(java.nio.file.Paths.get(dataPath("portable-runtime.properties")));
  if(portableMode) {
    webMode=true;
    try {
      fill(255); text("Preparing 404 FACE NOT FOUND...\nFirst run downloads camera support. Progress appears in the console.\nKeep Processing open. The website opens automatically when ready.",30,60);
      PortableRuntime.prepare(java.nio.file.Paths.get(sketchPath()).toAbsolutePath().normalize(),message -> { println(message); surface.setTitle(message); });
    } catch(Exception error) {
      portableError="Cannot prepare the local experience.\nCheck the network and run this sketch again.\n"+error.getMessage();
      println(portableError); surface.setTitle("404 FACE NOT FOUND — setup needs attention"); return;
    }
  }
  if(webMode) {
    try {
      java.nio.file.Path workspace=java.nio.file.Paths.get(sketchPath()).toAbsolutePath().normalize().getParent().getParent().getParent();
      java.nio.file.Path portableRoot=java.nio.file.Paths.get(sketchPath()).toAbsolutePath().normalize();
      web=new WebExperience(portableMode?portableRoot.resolve("data/web"):workspace.resolve("staging/frontend-design/selection-demo"),
        portableMode?portableRoot.resolve("data/runtime/events.json"):workspace.resolve("staging/frontend-design/local-runtime/events.json"),4173);
      println("Web experience: http://127.0.0.1:4173/");
    } catch(Exception e) {
      if(!portableMode)throw new RuntimeException("Cannot start local website",e);
      portableError="Cannot open local port 4173.\nStop an earlier copy of this project and run again.\n"+e.getMessage();println(portableError);return;
    }
    if(!portableMode)surface.setVisible(false);
  }
  println("Arduino ports:"); printArray(Serial.list());
  try {
  small = createImage(CW, CH, RGB);
  if(!portableMode)nu.pattern.OpenCV.loadLocally();
  if(portableMode) {
    try {
      org.opencv.core.MatOfByte model=new org.opencv.core.MatOfByte(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(dataPath("face_detection_yunet_2023mar.onnx"))));
      org.opencv.core.MatOfByte config=new org.opencv.core.MatOfByte();
      try { faceDetector=FaceDetectorYN.create("onnx",model,config,new Size(CW,CW),.65f,.3f,5000); }
      finally { model.release();config.release(); }
    } catch(java.io.IOException error) { throw new RuntimeException("Cannot read the bundled face model",error); }
  } else faceDetector=FaceDetectorYN.create(dataPath("face_detection_yunet_2023mar.onnx"),"",new Size(CW,CW),.65f,.3f,5000);
  faceInput=new Mat(); faceDetections=new Mat();
  handFrame = new Mat(CH,CW,CvType.CV_8UC3);
  handTracker = new HandTracker(dataPath("palm_detection_mediapipe_2023feb.onnx"),
    dataPath("handpose_estimation_mediapipe_2023feb.onnx"));
  } catch(RuntimeException error) {
    if(!portableMode)throw error;
    portableError="Cannot initialize the bundled recognition models.\nExtract the whole project again and retry.\n"+error.getMessage();
    println(portableError);if(web!=null){web.close();web=null;}return;
  }
  if(!webMode) startWebCamera();
  lastDraw=millis();
  if(portableMode) { surface.setTitle("404 FACE NOT FOUND — local engine running");surface.setVisible(false);if(!Boolean.getBoolean("dpm.noBrowser"))link("http://127.0.0.1:4173/#guide"); }
}
void startWebCamera() {
  engineError="";
  try {
    String[] devices=Capture.list();
    if(CAMERA_INDEX<0 || CAMERA_INDEX>=devices.length) { engineError="camera-unavailable"; return; }
    camera=new Capture(this,devices[CAMERA_INDEX]); camera.start();
  } catch(Exception e) { engineError="camera-unavailable"; camera=null; }
}
JSONObject currentConfig() {
  JSONObject config=new JSONObject(); config.setString("shape",maskShape);
  config.setString("characters",maskText); config.setString("colour",String.format("#%06X",maskColour&0xffffff));
  config.setInt("movement",maskMovement); config.setInt("density",maskDensity); return config;
}
void applyWebConfig(JSONObject config) {
  maskShape=config.getString("shape"); maskText=config.getString("characters");
  maskColour=0xff000000|Integer.parseInt(config.getString("colour").substring(1),16);
  maskMovement=config.getInt("movement"); maskDensity=config.getInt("density"); MASK_COLUMNS=round(56*maskDensity/72.0f);
  MASK_ROWS=round(48*config.getInt("density")/72.0f);
  maskWidth=maskShape.equals("wing")?1.13f:maskShape.equals("arc")?.96f:maskShape.equals("petal")?.98f:
    maskShape.equals("ribbon")?1.08f:maskShape.equals("veil")?.82f:maskShape.equals("echo")?.93f:1;
  MASK_DIGIT_STEP_MS=round(lerp(600,100,maskMovement/100.0f));
  if(maskCharacters!=null) maskCharacters.dispose(); if(maskGlow!=null) maskGlow.dispose(); if(maskComposite!=null) maskComposite.dispose();
  maskCharacters=null; cachedFaceBlurRisk=-1; cachedMaskRisk=-1; configVersion++;
}
public void draw() {
  if(!portableError.isEmpty()){background(20);fill(255);text(portableError,24,35,width-48,height-60);return;}
  int now=millis();
  if(webMode) {
    JSONObject config=web.takeConfig(); if(config!=null) applyWebConfig(config);
    boolean requested=web.wantsSession();
    if(requested!=sessionActive) {
      sessionActive=requested; clearPhotoTracking(); face=null; previousFace=null; faceVisible=false; hands=new ArrayList<HandTracker.Hand>(); faceSeenAt=-10000; frameAt=-10000;
      if(sessionActive) startWebCamera();
      else { if(camera!=null) { try { camera.stop(); } catch(Exception ignored) { } camera=null; } web.clearFrame(); }
    }
  }
  float dt=constrain((now-lastDraw)/1000.0f,0,0.1f); lastDraw=now;
  if((!webMode || sessionActive) && (arduino==null || now-max(sensorState.lastPacketAt(),openedAt)>4000)) connectArduino();
  if(camera!=null && camera.available()) {
    camera.read(); frameAt=millis();
    if(frameAt-lastAnalysis>=100) {
      lastAnalysis=frameAt;
      analyseFrame();
      updateActivation(millis());
    }
  }
  now=millis();
  if(now-frameAt>800) {
    face=null; previousFace=null; faceVisible=false; hands=new ArrayList<HandTracker.Hand>(); clearPhotoTracking();
  }
  DistanceSensorState.Sample distanceSample=sensorState.snapshot(now);
  distanceCm=distanceSample.cm;
  boolean sensorOK=distanceCm>=2;
  boolean intent=protectionActive(now);
  updateRisk(intent && sensorOK,dt);
  background(20);
  pushMatrix();
  scale(width / 640.0f, height / 480.0f);
  renderCameraScene(camera,now);
  if(!webMode) {
  noFill(); strokeWeight(2);
  stroke(intent?color(60,255,100):color(255,200,40));
  rect(1,1,638,478);
  fill(255); textSize(13);
  text(intent?"ACTIVATED":gestureDetected?"HOLD PHOTO FRAME":"MAKE A PHOTO FRAME",12,24);
  noFill();
  }
  popMatrix();
  if(webMode) {
    if(sessionActive && now-frameAt<=800 && now-lastWebPublish>=100) {
      web.publishFrame(get(),640,480); lastWebPublish=now;
    }
    web.observe(intent,currentConfig(),sensorOK,distanceCm,risk,!sessionActive?"session-ended":now-frameAt>800?"camera-lost":face==null?"face-lost":"released");
    JSONObject state=new JSONObject(); state.setBoolean("session",sessionActive); state.setBoolean("camera",sessionActive && now-frameAt<=800);
    state.setBoolean("face",face!=null); state.setBoolean("faceVisible",faceVisible); state.setInt("hands",hands.size());
    state.setBoolean("gesture",gestureDetected); state.setBoolean("active",intent); state.setBoolean("sensor",sensorOK);
    state.setFloat("distance",sensorOK?distanceCm:-1); state.setFloat("risk",sensorOK && intent?risk:-1);
    state.setFloat("distanceRisk",sensorOK?riskForDistance(distanceCm):-1);
    state.setInt("distanceAgeMs",sensorOK?now-distanceSample.at:-1);
    state.setString("serialStatus",serialMessage);
    state.setInt("serialPacketAgeMs",sensorState.lastPacketAt()>=0?max(0,now-sensorState.lastPacketAt()):-1);
    state.setFloat("nearDistance",NEAR_CM); state.setFloat("farDistance",FAR_CM);
    state.setFloat("hold",gestureSince<0?0:constrain((now-gestureSince)/(float)GESTURE_HOLD_MS,0,1));
    state.setString("hint",gestureHint); state.setString("error",engineError); state.setInt("configVersion",configVersion);
    state.setFloat("handAnalysisMs",handAnalysisMs);
    state.setBoolean("skeleton",sessionActive && now-frameAt<=800 && !hands.isEmpty());
    processing.data.JSONArray handHints=new processing.data.JSONArray();
    for(HandTracker.Hand hand:hands) handHints.append(hand.hint);
    state.setJSONArray("handHints",handHints);
    state.setJSONObject("config",currentConfig()); state.setLong("time",System.currentTimeMillis()); web.publishState(state);
    return;
  }
  noStroke(); fill(0,210); rect(0,height-75,width,75); fill(255); textSize(17);
  text("Distance: "+(sensorOK?nf(distanceCm,0,1)+" cm":"INVALID")+
       " | Risk: "+nf(risk,0,2)+" | Intent: "+intent,15,height-50);
  text("Hands: "+hands.size()+" | L: "+((leftL?1:0)+(rightL?1:0))+" | Face: "+(faceVisible?"visible":face!=null?"tracked":"not found")+
       (intent?" | Active; hands may leave":
       gestureDetected?" | Hold: "+nf((now-gestureSince)/1000.0f,0,1)+"s":" | "+gestureHint),15,height-28);
  text(serialMessage+" | Hand analysis: "+round(handAnalysisMs)+" ms",15,height-7);
}
public void connectArduino() {
  int now=millis(); if(now-retryAt<3000) return; retryAt=now;
  try {
    String port=SERIAL_PORT.trim();
    if(port.length()==0) {
      ArrayList<String> ports=new ArrayList<String>();
      for(String p:Serial.list()) {
        String q=p.toLowerCase();
        if(p.startsWith("COM") || p.startsWith("/dev/ttyACM") || p.startsWith("/dev/ttyUSB") || (p.startsWith("/dev/cu.") &&
          (q.contains("usbmodem") || q.contains("usbserial") || q.contains("wch")))) ports.add(p);
      }
      if(ports.size()!=1) { serialMessage="Set SERIAL_PORT to your Arduino port"; return; }
      port=ports.get(0);
    }
    if(arduino!=null) arduino.stop(); arduino=null; sensorState.reset();
    arduino=new Serial(this,port,115200); arduino.clear(); arduino.bufferUntil('\n');
    openedAt=now; serialMessage="Arduino connected";
  } catch(Exception e) { arduino=null; sensorState.reset(); serialMessage="Serial connection failed"; println(e.getMessage()); }
}
public void serialEvent(Serial port) {
  if(port!=arduino) return;
  try { sensorState.accept(port.readStringUntil('\n'),millis()); }
  catch(Exception ignored) { } // A partial packet must not overwrite a fresh valid sample.
}
public void analyseFrame() {
  small.copy(camera,0,0,camera.width,camera.height,0,0,CW,CH); small.loadPixels();
  detectPhotoGesture();
  face=selectFaceAnchor(detectFaceBoxes(),millis());
}
public Rect[] detectFaceBoxes() {
  int padding=(CW-CH)/2;
  org.opencv.core.Core.copyMakeBorder(handFrame,faceInput,padding,CW-CH-padding,0,0,org.opencv.core.Core.BORDER_CONSTANT,org.opencv.core.Scalar.all(0));
  faceDetector.detect(faceInput,faceDetections);
  ArrayList<Rect> boxes=new ArrayList<Rect>();
  for(int row=0;row<faceDetections.rows();row++) {
    float[] data=new float[15]; faceDetections.get(row,0,data);
    int x=max(0,round(data[0])),y=max(0,round(data[1])-padding);
    int right=min(CW,round(data[0]+data[2])),bottom=min(CH,round(data[1]+data[3])-padding);
    if(right-x>=28 && bottom-y>=28) boxes.add(new Rect(x,y,right-x,bottom-y));
  }
  return boxes.toArray(new Rect[0]);
}
public Rect selectFaceAnchor(Rect[] detected,int now) {
  faceVisible=detected.length==1;
  if(faceVisible) { previousFace=detected[0]; faceSeenAt=now; return previousFace; }
  // Keep only a recently observed single-face position. Once triggered, hands
  // may leave; temporary hand/face detection misses must not clear the mask.
  if(detected.length==0 && previousFace!=null && now-faceSeenAt<=FACE_OCCLUSION_MS
      && (protectionLatched || !hands.isEmpty())) return previousFace;
  return null;
}
public void updateActivation(int now) {
  if(!hands.isEmpty()) lastHandAt=now;
  else if(protectionLatched && now-lastHandAt>HANDS_GONE_MS) protectionLatched=false;
  if(face==null) { clearPhotoTracking(); return; }
  if(gestureDetected) {
    if(gestureSince<0 || now-lastGestureAt>GESTURE_GAP_MS) { gestureSince=now; gestureSamples=0; }
    lastGestureAt=now; gestureSamples++;
    if(now-gestureSince>=GESTURE_HOLD_MS && gestureSamples>=3) protectionLatched=true;
  } else if(now-lastGestureAt>GESTURE_GAP_MS) { gestureSince=-1; gestureSamples=0; }
}
public boolean protectionActive(int now) {
  return face!=null && now-frameAt<=800 && protectionLatched;
}
public void renderProtection(PImage frame,float viewWidth,float viewHeight,int now) {
  if(!protectionActive(now)) return;
  drawFaceBlur(frame,viewWidth,viewHeight);
  drawMask();
}
public void renderCameraScene(PImage frame,int now) {
  if(now-frameAt>800 || frame==null) return;
  image(frame,0,0,640,480);
  renderProtection(frame,640,480,now);
  drawHands();
}
public void clearPhotoTracking() {
  leftL=false; rightL=false; gestureDetected=false;
  leftHandBox=null; rightHandBox=null; gestureSince=-1; protectionLatched=false;
  lastGestureAt=-10000; gestureSamples=0;
  lastHandAt=-10000;
}
public void detectPhotoGesture() {
  for(int i=0;i<CW*CH;i++) {
    int p=small.pixels[i]; handBytes[i*3]=(byte)(p&255);
    handBytes[i*3+1]=(byte)((p>>8)&255); handBytes[i*3+2]=(byte)((p>>16)&255);
  }
  handFrame.put(0,0,handBytes);
  long start=System.nanoTime(); hands=handTracker.detect(handFrame);
  handAnalysisMs=(System.nanoTime()-start)/1000000.0f;
  applyHands(hands);
}
public void applyHands(java.util.List<HandTracker.Hand> current) {
  hands=current;
  leftL=false; rightL=false; gestureDetected=false; leftHandBox=null; rightHandBox=null;
  int count=0;
  for(HandTracker.Hand hand:current) if(hand.isL) {
    if(count++==0) { leftL=true; leftHandBox=hand.box; }
    else { rightL=true; rightHandBox=hand.box; }
  }
  if(current.size()==2) gestureDetected=HandTracker.formsFrame(current.get(0),current.get(1));
  gestureHint=current.size()<2?"SHOW BOTH HANDS":"TURN L CORNERS INWARD";
  if(current.size()==2 && count<2) for(HandTracker.Hand hand:current) if(!hand.isL) { gestureHint=hand.hint; break; }
}
public void drawHands() {
  pushStyle();
  int[][] links={{0,1,2,3,4},{0,5,6,7,8},{5,9,10,11,12},{9,13,14,15,16},{13,17,18,19,20},{0,17}};
  for(HandTracker.Hand hand:hands) {
    stroke(hand.isL?color(60,255,100):color(255,200,40)); strokeWeight(1.2f); noFill();
    for(int[] chain:links) for(int j=1;j<chain.length;j++) {
      float[] a=hand.points[chain[j-1]],b=hand.points[chain[j]];
      line(a[0]*2,a[1]*2,b[0]*2,b[1]*2);
    }
    noStroke(); fill(hand.isL?color(120,255,160):color(255,218,120));
    for(float[] point:hand.points) ellipse(point[0]*2,point[1]*2,3.4f,3.4f);
    if(!webMode) { fill(255); textSize(10); text(hand.hint,max(4,hand.box.x*2),max(40,hand.box.y*2-6)); }
  }
  popStyle();
}
public void updateRisk(boolean active,float dt) {
  if(!active) { risk=0; return; }
  float target=riskForDistance(distanceCm);
  risk=lerp(risk,target,1-exp(-dt/0.25f));
}
public float riskForDistance(float cm) {
  return constrain((FAR_CM-cm)/max(1.0f,FAR_CM-NEAR_CM),0,1);
}
public void drawMask() {
  // Render at a fixed resolution; only placement/scale follows the face each frame.
  float visualRisk = round(risk * 40.0f) / 40.0f;
  int now = millis();
  int phase = visualRisk > 0 ? now / 180 : 0;
  int digitPhase = now / max(80, MASK_DIGIT_STEP_MS);
  if (maskCharacters == null || visualRisk != cachedMaskRisk || phase != cachedMaskPhase
      || MASK_COLUMNS != cachedMaskColumns || MASK_ROWS != cachedMaskRows
      || MASK_GLOW_RADIUS != cachedGlowRadius || MASK_GLOW_STRENGTH != cachedGlowStrength
      || digitPhase != cachedDigitPhase || MASK_DIGIT_STEP_MS != cachedDigitStep
      || MASK_DIGIT_GROUPS != cachedDigitGroups) {
    rebuildMaskLayers(visualRisk, phase, digitPhase);
  }
  float scaleX = face.width * 2.0f / MASK_FACE_SIZE;
  float scaleY = face.height * 2.0f / MASK_FACE_SIZE;
  float cx = (face.x + face.width * 0.5f) * 2.0f;
  float x = cx + (maskSpriteX - MASK_TEXTURE_SIZE * 0.5f) * scaleX;
  float y = face.y * 2.0f + (maskSpriteY - MASK_TOP_PADDING) * scaleY;
  pushStyle();
  imageMode(CORNER);
  noTint();
  image(maskSprite, x, y, maskSprite.width * scaleX, maskSprite.height * scaleY);
  popStyle();
}

public void drawFaceBlur(PImage frame, float viewWidth, float viewHeight) {
  if (face == null || frame == null || frame.width <= 0 || frame.height <= 0) return;
  float visualRisk = round(risk * 40.0f) / 40.0f;
  float expansionX = maskWidth * (1.0f + visualRisk * 0.30f);
  float expansionY = 1.0f + visualRisk * 0.12f;
  float halfSpan = 0.465f * expansionX + 0.04f;
  float fw = face.width * 2.0f, fh = face.height * 2.0f;
  float cx = (face.x + face.width * 0.5f) * 2.0f;
  float x = cx - fw * halfSpan, y = face.y * 2.0f + fh * 0.10f;
  float w = fw * halfSpan * 2.0f, h = fh * 1.15f;
  if (faceBlurSample == null) {
    faceBlurSample = createImage(FACE_BLUR_SAMPLE_SIZE, FACE_BLUR_SAMPLE_SIZE, RGB);
    faceBlurLayer = createImage(FACE_BLUR_LAYER_SIZE, FACE_BLUR_LAYER_SIZE, ARGB);
    faceBlurAlpha = new int[FACE_BLUR_LAYER_SIZE * FACE_BLUR_LAYER_SIZE];
  }
  if (visualRisk != cachedFaceBlurRisk || FACE_BLUR_OPACITY != cachedFaceBlurOpacity
      || FACE_BLUR_FEATHER != cachedFaceBlurFeather) {
    for (int row = 0; row < FACE_BLUR_LAYER_SIZE; row++) {
      float v = 0.72f + (0.10f + (row + 0.5f) / FACE_BLUR_LAYER_SIZE * 1.15f - 0.72f) / expansionY;
      for (int column = 0; column < FACE_BLUR_LAYER_SIZE; column++) {
        float u = ((column + 0.5f) / FACE_BLUR_LAYER_SIZE - 0.5f) * halfSpan * 2.0f / (0.465f * expansionX);
        float edge = min(min(v - maskUpperEdge(u), maskLowerEdge(u) - v), (1.0f - abs(u)) * 0.3f);
        float fade = constrain(edge / max(0.001f, FACE_BLUR_FEATHER), 0, 1);
        fade = fade * fade * (3.0f - 2.0f * fade);
        faceBlurAlpha[row * FACE_BLUR_LAYER_SIZE + column] = round(constrain(FACE_BLUR_OPACITY, 0, 255) * fade);
      }
    }
    cachedFaceBlurRisk = visualRisk;
    cachedFaceBlurOpacity = FACE_BLUR_OPACITY;
    cachedFaceBlurFeather = FACE_BLUR_FEATHER;
  }

  // Resample current camera pixels, blur at low resolution, then apply a filled
  // silhouette so gaps between the changing digits also obscure facial detail.
  frame.loadPixels();
  faceBlurSample.loadPixels();
  for (int row = 0; row < FACE_BLUR_SAMPLE_SIZE; row++) {
    int sy = constrain(floor((y + (row + 0.5f) / FACE_BLUR_SAMPLE_SIZE * h) / viewHeight * frame.pixelHeight), 0, frame.pixelHeight - 1);
    for (int column = 0; column < FACE_BLUR_SAMPLE_SIZE; column++) {
      int sx = constrain(floor((x + (column + 0.5f) / FACE_BLUR_SAMPLE_SIZE * w) / viewWidth * frame.pixelWidth), 0, frame.pixelWidth - 1);
      faceBlurSample.pixels[row * FACE_BLUR_SAMPLE_SIZE + column] = 0xff000000 | (frame.pixels[sy * frame.pixelWidth + sx] & 0x00ffffff);
    }
  }
  faceBlurSample.updatePixels();
  faceBlurSample.filter(BLUR, max(0.1f, FACE_BLUR_RADIUS));
  PImage softened = faceBlurSample.get();
  softened.resize(FACE_BLUR_LAYER_SIZE, FACE_BLUR_LAYER_SIZE);
  softened.loadPixels();
  faceBlurLayer.loadPixels();
  for (int i = 0; i < faceBlurLayer.pixels.length; i++) {
    faceBlurLayer.pixels[i] = (faceBlurAlpha[i] << 24) | (softened.pixels[i] & 0x00ffffff);
  }
  faceBlurLayer.updatePixels();
  pushStyle(); imageMode(CORNER); noTint();
  image(faceBlurLayer, x, y, w, h);
  popStyle();
}

public float maskUpperEdge(float u) {
  float side=abs(u), gaussian=exp(-u*u/.06f);
  if(maskShape.equals("arc")) return .44f-.14f*gaussian-.12f*pow(side,3);
  if(maskShape.equals("wing")) return .54f-.18f*gaussian-.41f*pow(side,3);
  if(maskShape.equals("petal")) return .53f-.16f*gaussian-.23f*pow(side,5);
  if(maskShape.equals("ribbon")) return .52f-.12f*gaussian-.18f*pow(side,3);
  if(maskShape.equals("veil")) return .57f-.20f*gaussian-.29f*pow(side,8);
  if(maskShape.equals("facet")) return .38f+.22f*min(side/.4f,1)-.4f*max((side-.4f)/.6f,0);
  if(maskShape.equals("echo")) return .47f-.16f*gaussian-.12f*pow(side,5);
  return 0.58f - 0.20f * exp(-u * u / 0.06f) - 0.38f * pow(abs(u), 10.0f);
}

public float maskLowerEdge(float u) {
  float side=abs(u);
  if(maskShape.equals("arc")) return .93f-.39f*u*u;
  if(maskShape.equals("wing")) return .91f-.36f*pow(side,1.7f);
  if(maskShape.equals("petal")) return 1.06f-.45f*pow(side,1.4f)+.065f*cos(u*PI*3);
  if(maskShape.equals("ribbon")) return .74f-.28f*u*u;
  if(maskShape.equals("veil")) return 1.24f-.78f*pow(side,1.25f);
  if(maskShape.equals("facet")) return side<.4f?1.08f-.1f*side/.4f:.98f-.42f*(side-.4f)/.6f;
  if(maskShape.equals("echo")) return 1.02f-.57f*pow(side,1.3f);
  return 1.13f - 0.58f * pow(abs(u), 1.35f);
}

public void rebuildMaskLayers(float visualRisk, int phase, int digitPhase) {
  boolean rebuildGlow = maskCharacters == null || visualRisk != cachedMaskRisk
    || phase != cachedMaskPhase || MASK_COLUMNS != cachedMaskColumns
    || MASK_ROWS != cachedMaskRows || MASK_GLOW_RADIUS != cachedGlowRadius;
  if (maskFont == null) {
    maskFont = new PFont(
      new java.awt.Font("Monospaced", java.awt.Font.BOLD, 32), true
    );
  }
  if (maskCharacters == null) {
    maskCharacters = createMaskLayer();
    maskGlow = createMaskLayer();
    maskComposite = createMaskLayer();
  }
  float fw = MASK_FACE_SIZE, fh = MASK_FACE_SIZE;
  float cx = MASK_TEXTURE_SIZE * 0.5f, top = MASK_TOP_PADDING;

  int columns = MASK_COLUMNS;
  int rows = MASK_ROWS;

  maskCharacters.beginDraw();
  maskCharacters.clear();
  maskCharacters.textFont(maskFont);
  maskCharacters.textAlign(CENTER, CENTER);
  maskCharacters.noStroke();

  for (int row = 0; row < rows; row++) {
    float v = 0.12f + (row + 0.5f) / rows * 1.16f;

    for (int column = 0; column < columns; column++) {
      float u = (column + 0.5f) / columns * 2.0f - 1.0f;
      float side = abs(u);

      // Raised nose centre and cheek sides; leave space below both eyes.
      float upper = maskUpperEdge(u);

      // Taper the lower edge toward the chin.
      float lower = maskLowerEdge(u);

      if (v < upper || v > lower) {
        continue;
      }
      if(maskShape.equals("echo") && ((int)((v-upper)/max(.001f,lower-upper)*7))%2==1) continue;

      int cell = maskCellHash(column, row);
      float variation = (cell % 101) / 100.0f;
      float px = u * fw * 0.465f * maskWidth;
      float py = v * fh;
      px += (variation - 0.5f) * fw / columns * 0.16f;
      py += (((cell / 101) % 101) / 100.0f - 0.5f) * fh / rows * 0.10f;

      // Keep the wrapping shape while risk drives expansion and disturbance.
      px *= 1.0f + visualRisk * 0.30f;
      py = fh * 0.72f + (py - fh * 0.72f) * (1.0f + visualRisk * 0.12f);
      px += visualRisk * (noise(column, row, phase * 0.28f) - 0.5f) * fw * 0.08f * maskMovement/35.0f;
      if(webMode) px += sin(row*.3f+digitPhase*.15f)*fw*.003f*maskMovement/35.0f;

      // Fade the border and slightly shrink the side characters.
      float edge = min(min(v - upper, lower - v), (1.0f - side) * 0.3f);
      float opacity = (95.0f + 155.0f * constrain(edge / 0.05f, 0, 1))
        * (0.90f + variation * 0.10f);
      float characterSize = max(3.0f, fw / columns * 1.50f
        * (0.92f + variation * 0.16f) * (1.0f - side * 0.06f));

      maskCharacters.fill((maskColour>>16)&255,(maskColour>>8)&255,maskColour&255,opacity);
      maskCharacters.textSize(characterSize);
      maskCharacters.text(maskDigitForCell(column, row, digitPhase), cx + px, top + py);
    }
  }

  maskCharacters.endDraw();
  PImage inkSnapshot = maskCharacters.get();

  // Blur the glyph alpha, then restore warm RGB so transparent pixels do not
  // create a dark fringe. This is a light field, without an opaque backing.
  if (rebuildGlow) {
    maskGlow.beginDraw();
    maskGlow.clear();
    maskGlow.image(inkSnapshot, 0, 0);
    maskGlow.filter(BLUR, max(0.1f, MASK_GLOW_RADIUS));
    maskGlow.loadPixels();
    for (int i = 0; i < maskGlow.pixels.length; i++) {
      maskGlow.pixels[i] = (maskGlow.pixels[i] & 0xff000000) | (maskColour & 0xffffff);
    }
    maskGlow.updatePixels();
    maskGlow.endDraw();
    maskGlowSnapshot = maskGlow.get();
  }

  // Composite once per rebuild, then crop transparent padding. Realtime drawing
  // uses one image; fresh pixels also avoid stale Java2D image caches on risk changes.
  maskComposite.beginDraw();
  maskComposite.clear();
  maskComposite.tint(255, constrain(MASK_GLOW_STRENGTH, 0, 255));
  maskComposite.image(maskGlowSnapshot, 0, 0);
  maskComposite.noTint();
  maskComposite.image(inkSnapshot, 0, 0);
  maskComposite.endDraw();
  maskComposite.loadPixels();
  int left = MASK_TEXTURE_SIZE, right = 0, upperY = MASK_TEXTURE_SIZE, bottom = 0;
  for (int y = 0; y < MASK_TEXTURE_SIZE; y++) {
    for (int x = 0; x < MASK_TEXTURE_SIZE; x++) {
      if ((maskComposite.pixels[y * MASK_TEXTURE_SIZE + x] >>> 24) == 0) continue;
      left = min(left, x); right = max(right, x);
      upperY = min(upperY, y); bottom = max(bottom, y);
    }
  }
  if (left > right || upperY > bottom) { left = upperY = right = bottom = 0; }
  maskSpriteX = left; maskSpriteY = upperY;
  maskSprite = maskComposite.get(left, upperY, right - left + 1, bottom - upperY + 1);
  cachedMaskRisk = visualRisk;
  cachedMaskPhase = phase;
  cachedMaskColumns = MASK_COLUMNS;
  cachedMaskRows = MASK_ROWS;
  cachedGlowRadius = MASK_GLOW_RADIUS;
  cachedGlowStrength = MASK_GLOW_STRENGTH;
  cachedDigitPhase = digitPhase;
  cachedDigitStep = MASK_DIGIT_STEP_MS;
  cachedDigitGroups = MASK_DIGIT_GROUPS;
}

public String maskDigitForCell(int column, int row, int digitPhase) {
  int cell = maskCellHash(column, row);
  if(!maskText.equals("01")) {
    int[] chars=maskText.codePoints().toArray(); int index=(cell+digitPhase/max(1,MASK_DIGIT_GROUPS))%chars.length;
    return new String(Character.toChars(chars[index]));
  }
  int groups = max(1, MASK_DIGIT_GROUPS);
  int offset = (cell / 101) % groups;
  boolean one = cell % 100 < 58;
  if (((digitPhase + offset) / groups) % 2 == 1) one = !one;
  return one ? "1" : "0";
}

public PGraphics createMaskLayer() {
  PGraphics layer = createGraphics(MASK_TEXTURE_SIZE, MASK_TEXTURE_SIZE, JAVA2D);
  // Keep alpha/crop coordinates consistent on Windows displays with 125%/150% scaling.
  layer.pixelDensity = 1;
  layer.setSize(MASK_TEXTURE_SIZE, MASK_TEXTURE_SIZE);
  return layer;
}

// Stable variation avoids a checkerboard without random flicker each frame.
public int maskCellHash(int column, int row) {
  int value = (column + 1) * 73856093 ^ (row + 1) * 19349663;
  value ^= value >>> 13;
  value *= 1274126177;
  return value & 0x7fffffff;
}

public void exit() {
  if(web!=null) { web.observe(false,currentConfig(),false,-1,0,"engine-stopped"); web.close(); }
  try { if(arduino!=null) arduino.stop(); } catch(Exception ignored) { }
  try { if(camera!=null) camera.stop(); } catch(Exception ignored) { }
  if(faceInput!=null) faceInput.release(); if(faceDetections!=null) faceDetections.release();
  if(maskCharacters!=null) maskCharacters.dispose(); if(maskGlow!=null) maskGlow.dispose();
  if(maskComposite!=null) maskComposite.dispose();
  super.exit();
}
