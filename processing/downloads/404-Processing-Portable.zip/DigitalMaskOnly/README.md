# 404 FACE NOT FOUND — Portable Processing

1. Extract the whole ZIP to a writable folder. Keep `code/` and `data/` next to the sketch.
2. In Processing 4.5.7 (Java mode), open `DigitalMaskOnly.pde` and press Run (▶).
3. First Run downloads the camera runtime for your OS (roughly 40–150 MB). Keep Processing open. Downloads are checksum-verified and cached beside this sketch.
4. The local website opens automatically when ready. Choose Begin to enable the camera. You can also return to the public page and connect with your mask settings.
5. Stop the sketch in Processing when finished. Images stay on the device; event metadata is in `data/runtime/events.json`.

Windows x64, macOS Intel / Apple Silicon and Linux x64 runtime files are included in the download service. Windows is tested on a real camera; macOS and Linux packages have not been tested on physical machines. Linux may require distribution-provided system libraries and camera/serial permissions. Older Processing versions, Windows ARM, Linux ARM and mobile devices are not claimed to work.

Arduino is optional for camera/gesture/mask interaction. Real distance and Risk require Arduino + HC-SR04; without it they remain unknown. No simulated distance is substituted.

No PowerShell, Git, Node, Python or separate Java install is needed to run the sketch. An Internet connection is required on the first Run. If preparation fails, check Processing’s console, verify network access to GitHub Pages, then press Run again. If port 4173 is busy, stop an earlier copy first.

Dependencies: Processing Video 2.2.2 (LGPL 2.1+, original Java sources included in `data/licenses/video/src`), JNA and gst1-java-core (notices embedded in their JARs), OpenPnP OpenCV 4.9.0-0 (native files separated; Java classes unchanged), and OpenCV Zoo models with their supplied notices. Dependency JARs remain replaceable in `code/`.

Upstream source: https://github.com/processing/processing-video/releases/tag/latest
OpenCV source: https://github.com/openpnp/opencv/tree/v4.9.0-0
Model source: https://github.com/opencv/opencv_zoo/tree/47534e27c9851bb1128ccc0102f1145e27f23f98
