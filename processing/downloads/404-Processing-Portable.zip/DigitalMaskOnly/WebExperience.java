import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import processing.data.JSONObject;
import processing.data.JSONArray;
import processing.core.PImage;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/** Loopback presentation adapter inside Processing. No camera or recognition here. */
public final class WebExperience implements AutoCloseable {
  private final HttpServer server;
  private final ExecutorService workers = Executors.newFixedThreadPool(4);
  private final Path root, store;
  private JSONArray events = new JSONArray();
  private JSONObject state = new JSONObject(), pendingConfig;
  private volatile byte[] frame;
  private volatile long frameAt, heartbeat;
  private volatile boolean requested;
  private boolean storageOK = true;
  private JSONObject event;
  private long eventStart;
  private int eventNumber;
  private final String runId = UUID.randomUUID().toString().substring(0,8);
  private static final Set<String> SHAPES = new HashSet<>(Arrays.asList("base","arc","wing","petal","ribbon","veil","facet","echo"));

  public WebExperience(Path root, Path store, int port) throws IOException {
    this.root = root.toAbsolutePath().normalize(); this.store = store;
    if (Files.exists(store)) {
      try { events = JSONArray.parse(Files.readString(store)); if (events == null) throw new IOException("Invalid history"); }
      catch (Exception e) { storageOK = false; } // Never overwrite an unreadable history file.
    }
    server = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 16);
    server.setExecutor(workers); server.createContext("/", this::handle); server.start();
  }
  public int port() { return server.getAddress().getPort(); }
  public boolean wantsSession() { return requested && System.currentTimeMillis()-heartbeat < 8000; }
  public synchronized JSONObject takeConfig() { JSONObject next=pendingConfig; pendingConfig=null; return next; }
  public synchronized void publishState(JSONObject next) { state=next; }
  public synchronized JSONObject snapshot() {
    JSONObject copy=JSONObject.parse(state.toString());
    copy.setBoolean("storageOK",storageOK); copy.setInt("eventCount",events.size()+(event==null?0:1));
    return copy;
  }
  public void publishFrame(int[] pixels, int width, int height) {
    encodeFrame(pixels,width,height,width,height);
  }
  /** PImage dimensions are logical units; JPEG rows must use the physical pixel stride. */
  public void publishFrame(PImage source, int width, int height) {
    source.loadPixels();
    encodeFrame(source.pixels,source.pixelWidth,source.pixelHeight,width,height);
  }
  private void encodeFrame(int[] pixels, int sourceWidth, int sourceHeight, int width, int height) {
    if(pixels==null || sourceWidth<=0 || sourceHeight<=0 || width<=0 || height<=0
        || (long)sourceWidth*sourceHeight!=pixels.length) { clearFrame(); return; }
    try {
      BufferedImage source=new BufferedImage(sourceWidth,sourceHeight,BufferedImage.TYPE_INT_RGB);
      source.setRGB(0,0,sourceWidth,sourceHeight,pixels,0,sourceWidth);
      BufferedImage image=source;
      if(sourceWidth!=width || sourceHeight!=height) {
        image=new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
        java.awt.Graphics2D graphics=image.createGraphics();
        try {
          graphics.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION,java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR);
          graphics.drawImage(source,0,0,width,height,null);
        } finally { graphics.dispose(); }
      }
      ByteArrayOutputStream output=new ByteArrayOutputStream(); ImageIO.write(image,"jpg",output);
      frame=output.toByteArray(); frameAt=System.currentTimeMillis();
    } catch (IOException ignored) { frame=null; }
  }
  public void clearFrame() { frame=null; frameAt=0; }

  /** One event per activation window; holding the pose extends the same event. */
  public synchronized void observe(boolean active, JSONObject config, boolean sensorOK, float cm, float risk, String endReason) {
    long now=System.currentTimeMillis();
    if(active && event==null) {
      eventStart=now; event=new JSONObject();
      event.setString("id",runId+"-"+(++eventNumber)); event.setLong("time",now);
      event.setJSONObject("config",JSONObject.parse(config.toString()));
      event.setFloat("peakRisk",0); event.setBoolean("distanceAvailable",false);
      event.setBoolean("response",true); event.setString("status","active");
    }
    if(event!=null && active) {
      if(sensorOK) {
        event.setBoolean("distanceAvailable",true);
        event.setFloat("minDistance",Math.min(event.getFloat("minDistance",400),cm));
        event.setFloat("peakRisk",Math.max(event.getFloat("peakRisk"),risk));
      }
      event.setLong("duration",now-eventStart);
    }
    if(event!=null && !active) {
      event.setLong("duration",now-eventStart); event.setString("status","complete");
      event.setString("endReason",endReason); events.append(event); event=null; save();
    }
  }
  private void save() {
    if(!storageOK) return;
    try {
      Files.createDirectories(store.getParent());
      Path temp=store.resolveSibling(store.getFileName()+".tmp"); Files.writeString(temp,events.toString());
      try { Files.move(temp,store,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
      catch (AtomicMoveNotSupportedException e) { Files.move(temp,store,StandardCopyOption.REPLACE_EXISTING); }
    } catch(IOException e) { storageOK=false; }
  }
  private synchronized JSONArray history() {
    JSONArray result=JSONArray.parse(events.toString());
    if(event!=null) result.append(JSONObject.parse(event.toString()));
    return result;
  }
  public static JSONObject validateConfig(JSONObject input) {
    String shape=input.getString("shape",""), colour=input.getString("colour","");
    String characters=input.getString("characters","01").strip();
    if(!SHAPES.contains(shape) || !colour.matches("#[0-9a-fA-F]{6}") || characters.codePointCount(0,characters.length())>12
      || characters.codePoints().anyMatch(Character::isISOControl)) throw new IllegalArgumentException("Invalid mask configuration");
    int movement=input.getInt("movement"), density=input.getInt("density");
    if(movement<0 || movement>100 || density<30 || density>100) throw new IllegalArgumentException("Invalid mask range");
    JSONObject result=new JSONObject(); result.setString("shape",shape); result.setString("colour",colour.toUpperCase(Locale.ROOT));
    result.setString("characters",characters.isEmpty()?"01":characters); result.setInt("movement",movement); result.setInt("density",density);
    return result;
  }
  private void handle(HttpExchange x) throws IOException {
    try {
      String host=x.getRequestHeaders().getFirst("Host");
      String expected="127.0.0.1:"+port();
      if(!expected.equals(host) && !("localhost:"+port()).equals(host)) { reply(x,403,"text/plain","Local access only"); return; }
      x.getResponseHeaders().set("Cache-Control","no-store");
      x.getResponseHeaders().set("X-Content-Type-Options","nosniff");
      x.getResponseHeaders().set("Referrer-Policy","no-referrer");
      x.getResponseHeaders().set("Cross-Origin-Resource-Policy","same-origin");
      x.getResponseHeaders().set("Content-Security-Policy","default-src 'self'; img-src 'self' blob: data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'");
      String path=x.getRequestURI().getPath(), method=x.getRequestMethod();
      if(!method.equals("GET") && !method.equals("POST")) { reply(x,405,"text/plain","Method not allowed"); return; }
      if(method.equals("POST")) {
        String origin=x.getRequestHeaders().getFirst("Origin");
        if(origin!=null && !origin.equals("http://"+host)) { reply(x,403,"text/plain","Origin rejected"); return; }
        if(!"application/json".equals(x.getRequestHeaders().getFirst("Content-Type"))) { reply(x,415,"text/plain","JSON required"); return; }
        byte[] body=x.getRequestBody().readNBytes(4097);
        if(body.length>4096) { reply(x,413,"text/plain","Request too large"); return; }
        JSONObject input=JSONObject.parse(new String(body,StandardCharsets.UTF_8));
        if(input==null) throw new IllegalArgumentException("Invalid JSON");
        synchronized(this) {
          if(path.equals("/api/config")) pendingConfig=validateConfig(input);
          else if(path.equals("/api/session")) {
            boolean active=input.getBoolean("active");
            if(active && input.hasKey("config")) pendingConfig=validateConfig(input.getJSONObject("config"));
            requested=active; heartbeat=System.currentTimeMillis(); if(!active) clearFrame();
          } else { reply(x,404,"text/plain","Not found"); return; }
        }
        reply(x,202,"application/json","{\"accepted\":true}"); return;
      }
      if(path.equals("/api/state")) { reply(x,200,"application/json",snapshot().toString()); return; }
      if(path.equals("/api/events")) { reply(x,200,"application/json",history().toString()); return; }
      if(path.equals("/api/frame")) {
        byte[] bytes=frame;
        if(!wantsSession() || bytes==null || System.currentTimeMillis()-frameAt>1500) { reply(x,503,"text/plain","Frame unavailable"); return; }
        send(x,200,"image/jpeg",bytes); return;
      }
      Map<String,String> files=Map.of("/","index.html","/index.html","index.html","/styles.css","styles.css","/app.js","app.js","/design-data.js","design-data.js","/installation.js","installation.js","/experience.js","experience.js");
      String file=files.get(path);
      if(file==null) { reply(x,404,"text/plain","Not found"); return; }
      String type=file.endsWith(".css")?"text/css":file.endsWith(".js")?"text/javascript":"text/html";
      send(x,200,type,Files.readAllBytes(root.resolve(file)));
    } catch(Exception e) { reply(x,400,"application/json","{\"error\":\"Invalid request\"}"); }
    finally { x.close(); }
  }
  private static void reply(HttpExchange x,int status,String type,String body) throws IOException { send(x,status,type,body.getBytes(StandardCharsets.UTF_8)); }
  private static void send(HttpExchange x,int status,String type,byte[] body) throws IOException {
    x.getResponseHeaders().set("Content-Type",type+(type.startsWith("text/")||type.equals("application/json")?"; charset=utf-8":""));
    x.sendResponseHeaders(status,body.length); x.getResponseBody().write(body);
  }
  public void close() { requested=false; clearFrame(); server.stop(0); workers.shutdownNow(); }
}
