# 本机手部关键点模型

2026-10-17 用户明确允许在 Processing 原型中加入本机手部关键点识别。使用已有 OpenCV 4.9.0 Java DNN；不安装 Python、MediaPipe SDK、服务或网页框架。模型推理不联网，不保存 / 上传摄像头画面。这里只是原型实现授权，不是项目最终技术选型或隐私有效性证明。

来源为 [OpenCV Zoo](https://github.com/opencv/opencv_zoo/tree/47534e27c9851bb1128ccc0102f1145e27f23f98)，固定提交 `47534e27c9851bb1128ccc0102f1145e27f23f98`：

| 模型 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `palm_detection_mediapipe_2023feb.onnx` | 3905734 | `78ff51c38496b7fc8b8ebdb6cc8c1abb02fa6c38427c6848254cdaba57fcce7c` |
| `handpose_estimation_mediapipe_2023feb.onnx` | 4099621 | `db0898ae717b76b075d9bf563af315b29562e11f8df5027a1ef07b02bef6d81c` |

两个目录均按 Apache-2.0 提供，许可全文见 [LICENSE-OpenCV-HandModels.md](LICENSE-OpenCV-HandModels.md)。`HandTracker.java` 的预处理 / 解码依据同一提交的 [mp_palmdet.py](https://github.com/opencv/opencv_zoo/blob/47534e27c9851bb1128ccc0102f1145e27f23f98/models/palm_detection_mediapipe/mp_palmdet.py) 与 [mp_handpose.py](https://github.com/opencv/opencv_zoo/blob/47534e27c9851bb1128ccc0102f1145e27f23f98/models/handpose_estimation_mediapipe/mp_handpose.py) 移植；手部旋转裁剪合并成一次仿射变换，避免多次中间图像复制，边缘补黑。手势分类 / 时间门控为本工作副本逻辑。

模型二进制默认不进 Git。恢复版本后可运行 `tools/Setup-HandModels.ps1` 下载固定版本并核对哈希，已有正确文件不会重下。缺模型时程序明确报错，不改用运动触发。

验证工具 `tools/Test-HandModels.ps1` 使用公开的同提交 `palm_detection_mediapipe/example_outputs/mppalmdet_demo.gif` 首帧，文件本地保存在 `staging/teacher-prototype/hand-model-source/palm-example.gif`。可从 [固定来源](https://media.githubusercontent.com/media/opencv/opencv_zoo/47534e27c9851bb1128ccc0102f1145e27f23f98/models/palm_detection_mediapipe/example_outputs/mppalmdet_demo.gif) 重新取得；它不属于用户摄像头画面，不进 Git。
