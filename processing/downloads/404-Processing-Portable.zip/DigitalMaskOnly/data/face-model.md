# 本机面部定位

用户于 2026-10-20 反馈 Haar 面部定位不稳、手遮挡后口罩消失。当前在现有 Processing / OpenCV 4.9.0 内使用 YuNet 面部检测，不增加网页采集、云端推理或 SDK。

- [固定来源](https://github.com/opencv/opencv_zoo/tree/47534e27c9851bb1128ccc0102f1145e27f23f98/models/face_detection_yunet)：`face_detection_yunet_2023mar.onnx`，232589 字节。
- SHA-256：`8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4`，与官方固定提交的 Git LFS 指针核对。
- 许可：[MIT](LICENSE-OpenCV-FaceModel.md)。二进制留本机、不进 Git、不发布到公共网页；恢复运行 `tools/Setup-FaceModel.ps1`。
- 输入为摄像头缩小图，补边至 320×320；检测框映射回分析画面。短时遮挡最多保留最近确认的单人位置 4.5 秒；不代表完整遮挡跟踪或可靠性已验证。
