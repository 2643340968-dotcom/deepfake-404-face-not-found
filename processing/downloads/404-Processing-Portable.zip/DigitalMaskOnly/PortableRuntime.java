import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.function.Consumer;
import java.util.zip.*;

/** Dependencies for the downloadable sketch; never reads workspace-specific paths. */
public final class PortableRuntime {
  private static final String DOWNLOADS="https://2643340968-dotcom.github.io/deepfake-404-face-not-found/processing/downloads/native/v1/";
  public static String platform(String os,String arch) {
    os=os.toLowerCase(Locale.ROOT);arch=arch.toLowerCase(Locale.ROOT);
    boolean x64=arch.equals("amd64")||arch.equals("x86_64"),arm=arch.equals("aarch64")||arch.equals("arm64");
    if(os.startsWith("windows")&&x64)return "windows-amd64";
    if(os.contains("mac")&&(x64||arm))return arm?"macos-aarch64":"macos-x86_64";
    if(os.contains("linux")&&x64)return "linux-amd64";
    throw new IllegalArgumentException("Supported: Windows x64, macOS Intel/Apple Silicon, Linux x64. Detected: "+os+" / "+arch);
  }
  public static Path safeEntry(Path root,String name) throws IOException {
    Path target=root.resolve(name).normalize();
    if(name.contains("\\")||!target.startsWith(root)||target.equals(root)||Path.of(name).isAbsolute())throw new IOException("Invalid archive path");
    return target;
  }
  private static String sha(Path file) throws Exception {
    MessageDigest digest=MessageDigest.getInstance("SHA-256");
    try(InputStream in=Files.newInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)digest.update(b,0,n);}
    return HexFormat.of().formatHex(digest.digest());
  }
  private static void download(String name,String expected,long bytes,Path file,Consumer<String> progress) throws Exception {
    if(!name.matches("[a-z0-9-]+\\.zip")||!expected.matches("[a-f0-9]{64}")||bytes<=0||bytes>60L*1024*1024)throw new IOException("Invalid runtime manifest");
    if(Files.isRegularFile(file)&&Files.size(file)==bytes&&sha(file).equals(expected))return;
    URLConnection connection=URI.create(DOWNLOADS+name).toURL().openConnection();connection.setConnectTimeout(20000);connection.setReadTimeout(30000);
    Path partial=file.resolveSibling(file.getFileName()+".part");long total=0,last=0;
    try(InputStream in=connection.getInputStream();OutputStream out=Files.newOutputStream(partial)){
      byte[] buffer=new byte[65536];int n;
      while((n=in.read(buffer))!=-1){total+=n;if(total>bytes)throw new IOException("Runtime download exceeded expected size");out.write(buffer,0,n);
        if(total-last>1024*1024){progress.accept("Preparing camera support: "+name+" "+(total*100/bytes)+"%");last=total;}}
    }
    if(total!=bytes||!sha(partial).equals(expected))throw new IOException("Runtime checksum failed; run the sketch again to retry");
    Files.move(partial,file,StandardCopyOption.REPLACE_EXISTING);
  }
  private static void extract(Path archive,Path root) throws Exception {
    long total=0;int count=0;
    try(ZipInputStream zip=new ZipInputStream(Files.newInputStream(archive))){ZipEntry entry;byte[] buffer=new byte[65536];
      while((entry=zip.getNextEntry())!=null){if(++count>10000)throw new IOException("Too many runtime files");Path target=safeEntry(root,entry.getName());
        if(entry.isDirectory()){Files.createDirectories(target);continue;}Files.createDirectories(target.getParent());
        try(OutputStream out=Files.newOutputStream(target)){int n;while((n=zip.read(buffer))!=-1){total+=n;if(total>800L*1024*1024)throw new IOException("Runtime archive too large");out.write(buffer,0,n);}}
      }
    }
  }
  public static void prepare(Path sketch,Consumer<String> progress) throws Exception {
    // GLib accepts UTF-8 paths even when the Windows JVM's default charset is GBK.
    System.setProperty("jna.encoding","UTF-8");
    Path manifest=sketch.resolve("data/portable-runtime.properties");Properties settings=new Properties();
    try(Reader reader=Files.newBufferedReader(manifest,StandardCharsets.UTF_8)){settings.load(reader);}
    String platform=platform(System.getProperty("os.name"),System.getProperty("os.arch"));
    Path root=sketch.resolve("data/runtime/"+platform),cache=sketch.resolve("data/runtime/downloads");Files.createDirectories(cache);Files.createDirectories(root);
    String revision=sha(manifest);Path complete=root.resolve(".complete");
    Path cv=root.resolve("opencv/"+(platform.startsWith("windows")?"opencv_java490.dll":platform.startsWith("macos")?"libopencv_java490.dylib":"libopencv_java490.so"));
    if(!Files.isRegularFile(complete)||!Files.readString(complete).equals(revision)||!Files.isRegularFile(cv)||!Files.isDirectory(root.resolve("video/gstreamer-1.0"))){
      int count=Integer.parseInt(settings.getProperty(platform+".count","0"));if(count<1||count>20)throw new IOException("No runtime for "+platform);
      for(int i=0;i<count;i++){String[] part=settings.getProperty(platform+"."+i,"").split("\\|");if(part.length!=3)throw new IOException("Invalid runtime entry");
        Path archive=cache.resolve(part[0]);download(part[0],part[1],Long.parseLong(part[2]),archive,progress);progress.accept("Installing camera support "+(i+1)+" / "+count);extract(archive,root);}
      int links=Integer.parseInt(settings.getProperty(platform+".links","0"));
      for(int i=0;i<links;i++){
        String[] spec=settings.getProperty(platform+".link."+i,"").split("\\|");if(spec.length!=2)throw new IOException("Invalid native library link");
        Path link=safeEntry(root,spec[0]),target=link.getParent().resolve(spec[1]).normalize();
        if(!target.startsWith(root)||Path.of(spec[1]).isAbsolute())throw new IOException("Native library link escaped its runtime");
        if(!Files.exists(link,LinkOption.NOFOLLOW_LINKS))Files.createSymbolicLink(link,Path.of(spec[1]));
        else if(!Files.isSymbolicLink(link)||!Files.readSymbolicLink(link).equals(Path.of(spec[1])))throw new IOException("Unexpected file at native library link");
      }
      Files.writeString(complete,revision);
    }
    String video=root.resolve("video").toString();System.setProperty("java.library.path",video+File.pathSeparator+System.getProperty("java.library.path",""));
    System.load(cv.toAbsolutePath().toString());progress.accept("Ready — opening the local website");
  }
}
